import { add } from "./a.js";
export function say(str) {
  return str + add();
}
