export function add() {
  return "add";
}

//./src/index.js
