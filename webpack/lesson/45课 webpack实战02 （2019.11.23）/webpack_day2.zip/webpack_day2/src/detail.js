console.log("detail page");
