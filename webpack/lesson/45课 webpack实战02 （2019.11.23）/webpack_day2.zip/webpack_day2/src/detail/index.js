console.log("detail page!!!");
