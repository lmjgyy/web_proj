// import { add } from "./other.js";
// const json = require("./index.json");

// console.log(add(1, 2), json);
// import("./index.less");

// import pic from "./logo.png";
// console.log(pic);
// var img = new Image();
// img.src = pic;

// var root = document.getElementById("root");
// root.append(img);
consol.log("hello webpack");
